// script.js

var notificationShown = false; // Notification shown flag

// Listen for window resize event
window.addEventListener('resize', function() {
    // Get window width
    var windowWidth = window.innerWidth;

    // Dynamically adjust based on window width
    if (windowWidth <= 600) {
        // Apply mobile styles when window width is less than or equal to 600px
        applyMobileStyles();
    } else {
        // Apply default styles otherwise
        applyDefaultStyles();
    }
});

// Function to apply mobile styles
function applyMobileStyles() {
    var navbarItems = document.querySelectorAll('.navbar li');
    navbarItems.forEach(function(item) {
        item.style.display = 'block';
        item.style.margin = '10px 0';
    });
}

// Function to apply default styles
function applyDefaultStyles() {
    var navbarItems = document.querySelectorAll('.navbar li');
    navbarItems.forEach(function(item) {
        item.style.display = 'inline';
        item.style.marginRight = '20px';
    });
}

// Apply appropriate styles based on window width on initial load
if (window.innerWidth <= 600) {
    applyMobileStyles();
} else {
    applyDefaultStyles();
}

// Function to create notification
function createNotification() {
    if (!notificationShown && Notification.permission === "granted") {
        // If notification has not been shown and user has granted permission
        var notification = new Notification("Welcome!", {
            body: "Thank you for visiting our website."
        });
        notificationShown = true; // Set notification shown flag to true
    } else if (Notification.permission !== "denied" && !notificationShown) {
        // If user has not made a decision yet and notification has not been shown
        Notification.requestPermission().then(function(permission) {
            if (permission === "granted") {
                var notification = new Notification("Welcome!", {
                    body: "Thank you for visiting our website."
                });
                notificationShown = true; // Set notification shown flag to true
            }
        });
    }
}

// Call notification function
createNotification();

// Event handler
// Remove event listener for popping up alert when clicking on content area
// document.querySelector('.content').addEventListener('click', function() {
//     alert('You clicked on the content area!');
// });

// Color changer functionality
function changeColor(color) {
    var body = document.body;
    switch (color) {
        case 'blue':
            body.style.backgroundColor = '#cfe2ff'; // Blue
            break;
        case 'green':
            body.style.backgroundColor = '#d9f4d9'; // Green
            break;
        default:
            body.style.backgroundColor = '#ffffff'; // Default (white)
            break;
    }
}

// Form validation
var form = document.getElementById('myForm');
form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission behavior

    // Get values of form fields
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var age = document.getElementById('age').value;
    var gender = document.getElementById('gender').value;
    var message = document.getElementById('message').value;

    if (name.trim() === '' || email.trim() === '' || age.trim() === '' || gender === '') {
        alert('Please fill out all fields.');
        return;
    }

    // Pattern validation example
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    alert('Form submitted successfully!');
});
